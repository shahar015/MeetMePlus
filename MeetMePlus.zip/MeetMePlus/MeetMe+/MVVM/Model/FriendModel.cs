﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeetMe_.MVVM.Model
{
    internal class FriendModel: UserModel
    {


    }
}

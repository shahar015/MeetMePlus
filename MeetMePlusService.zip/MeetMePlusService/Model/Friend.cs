﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [DataContract]
    public class Friend : BaseEntity
    {
        User user1;
        User user2;

        [DataMember]
        public User User1
        {
            get { return user1; }
            set { user1 = value; }
        }

        [DataMember]
        public User User2
        {
            get { return user2; }
            set { user2 = value; }
        }

    }

    [CollectionDataContract]
    public class FriendsList : List<Friend>
    {
        public FriendsList() { }
        public FriendsList(IEnumerable<Friend> list) :
            base(list)
        { }
        public FriendsList(IEnumerable<BaseEntity> list) :
            base(list.Cast<Friend>().ToList())
        { }
    }
}

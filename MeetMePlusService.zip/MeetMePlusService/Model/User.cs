﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [DataContract]
    public class User : BaseEntity, ICloneable
    {

        private string firstName;
        private string lastName;
        private string phone;
        private string password;
        private string email;
        private bool gender;
        private string username;
        private DateTime birthday;
        private List<string> interests;
        private string profPicExt;
        private UserType userType;

        [DataMember]
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        [DataMember]
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        [DataMember]
        public string Phone
        {
            get { return phone; }
            set { phone = value; }
        }

        [DataMember]
        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        [DataMember]
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        [DataMember]
        public string Username
        {
            get { return username; }
            set { username = value; }
        }

        [DataMember]
        public DateTime Birthday
        {
            get { return birthday; }
            set { birthday = value; }
        }

        [DataMember]
        public List<string> Interests
        {
            get { return interests; }
            set { interests = value; }
        }

        [DataMember]
        public bool Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        [DataMember]
        public string ProfPicExt
        {
            get { return profPicExt; }
            set { profPicExt = value; }
        }

        [DataMember]
        public UserType UserType
        {
            get { return userType; }
            set { userType = value; }
        }

        public object Clone()
        {
            return this.MemberwiseClone();
        }


    }

    [CollectionDataContract]
    public class UsersList : List<User>
    {
        public UsersList() { }
        public UsersList(IEnumerable<User> list) :
            base(list)
        { }
        public UsersList(IEnumerable<BaseEntity> list) :
            base(list.Cast<User>().ToList())
        { }

    }
}

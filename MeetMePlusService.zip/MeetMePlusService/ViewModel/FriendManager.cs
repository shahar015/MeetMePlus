﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModel
{
    public class FriendManager : BaseDB
    {
        protected override BaseEntity NewEntity()
        {
            return new Friend() as BaseEntity;
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            Friend friend = (Friend)entity;
            friend.Id = int.Parse(reader["Id"].ToString());
            UserManager user = new UserManager();
            friend.User1 = user.SelectById(int.Parse(reader["user1"].ToString()));
            friend.User2 = user.SelectById(int.Parse(reader["user2"].ToString()));
            return friend;
        }



        public FriendsList SelectAll()
        {
            command.CommandText = "SELECT * FROM tblFriends";
            FriendsList friendsList = new FriendsList(base.Select());
            return friendsList;
        }

        public Friend SelectById(int id)
        {
            command.CommandText = string.Format("SELECT * FROM tblFriends WHERE Id='{0}'", id);
            FriendsList friendsList = new FriendsList(base.Select());
            if (friendsList.Count == 0)
            {
                return null;
            }
            return friendsList[0];
        }

        public FriendsList SelectByUser(User user)
        {
            command.CommandText = string.Format("SELECT * FROM tblFriends WHERE user1='{0}' OR user2='{0}'", user.Id);
            FriendsList friendsList = new FriendsList(base.Select());
            return friendsList;
        }

        public Friend SelectByUsers(User user1, User user2)
        {
            command.CommandText = string.Format("SELECT * FROM tblFriends WHERE (user1='{0}' AND user2='{1}') OR (user2='{0}' AND user1='{1}')", user1.Id, user2.Id);
            FriendsList friendsList = new FriendsList(base.Select());
            if (friendsList.Count == 0)
                return null;
            return friendsList[0];
        }

        public int Insert(Friend friend)
        {
            command.CommandText = string.Format("INSERT INTO [dbo].[tblFriends] ([user1], [user2]) VALUES (@user1, @user2)");
            command.Parameters.AddWithValue("@user1", friend.User1.Id);
            command.Parameters.AddWithValue("@user2", friend.User2.Id);
            return base.SaveChanges();
        }

        public int Update(Friend friend)
        {
            command.CommandText = string.Format("UPDATE [dbo].[tblFriends] SET [user1] = @user1, [user2] = @user2 WHERE (([Id] = @Original_Id)");
            command.Parameters.AddWithValue("@user1", friend.User1.Id);
            command.Parameters.AddWithValue("@user2", friend.User2.Id);
            command.Parameters.AddWithValue("@Original_Id", friend.Id);
            return base.SaveChanges();
        }

        public int Delete(Friend friend)
        {
            command.CommandText = string.Format("DELETE FROM [dbo].[tblFriends] WHERE ([Id] = @Original_Id)");
            command.Parameters.AddWithValue("@Original_Id", friend.Id);
            return base.SaveChanges();
        }

        public int DeleteByUser(User user)
        {
            command.CommandText = string.Format("DELETE FROM [dbo].[tblFriends] WHERE (([user1] = @Original_Id) OR ([user2] = @Original_Id))");
            command.Parameters.AddWithValue("@Original_Id", user.Id);
            return base.SaveChanges();
        }

    }
}

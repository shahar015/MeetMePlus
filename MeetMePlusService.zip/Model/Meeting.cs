﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [DataContract]
    public class Meeting : BaseEntity
    {
        private User creator;
        private DateTime meetingTime;
        private string name;
        private string description;
        private string location;

        [DataMember]
        public User Creator
        {
            get { return creator; }
            set { creator = value; }
        }

        [DataMember]
        public DateTime MeetingTime
        {
            get { return meetingTime; }
            set { meetingTime = value; }
        }

        [DataMember]
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        [DataMember]
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        [DataMember]
        public string Location
        {
            get { return location; }
            set { location = value; }
        }
    }

    [CollectionDataContract]
    public class MeetingsList : List<Meeting>
    {
        public MeetingsList() { }
        public MeetingsList(IEnumerable<Meeting> list) :
            base(list)
        { }
        public MeetingsList(IEnumerable<BaseEntity> list) :
            base(list.Cast<Meeting>().ToList())
        { }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [DataContract]
    public class Message : BaseEntity
    {
        private DateTime sendingTime;
        private User sender;
        private string content;
        private Chat chat;

        [DataMember]
        public DateTime SendingTime
        {
            get { return sendingTime; }
            set { sendingTime = value; }
        }

        [DataMember]
        public User Sender
        {
            get { return sender; }
            set { sender = value; }
        }

        [DataMember]
        public string Content
        {
            get { return content; }
            set { content = value; }
        }

        [DataMember]
        public Chat Chat
        {
            get { return chat; }
            set { chat = value; }
        }
    }

    [CollectionDataContract]
    public class MessagesList : List<Message>
    {
        public MessagesList() { }
        public MessagesList(IEnumerable<Message> list) :
            base(list)
        { }
        public MessagesList(IEnumerable<BaseEntity> list) :
            base(list.Cast<Message>().ToList())
        { }
    }
}

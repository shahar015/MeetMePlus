﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [DataContract]
    public class ParticipentInMeeting : BaseEntity
    {
        private User participent;
        private Meeting meeting;

        [DataMember]
        public User Participent
        {
            get { return participent; }
            set { participent = value; }
        }

        [DataMember]
        public Meeting Meeting
        {
            get { return meeting; }
            set { meeting = value; }
        }
    }

    [CollectionDataContract]
    public class ParticipentsInMeetingList : List<ParticipentInMeeting>
    {
        public ParticipentsInMeetingList() { }
        public ParticipentsInMeetingList(IEnumerable<ParticipentInMeeting> list) :
            base(list)
        { }
        public ParticipentsInMeetingList(IEnumerable<BaseEntity> list) :
            base(list.Cast<ParticipentInMeeting>().ToList())
        { }

    }
}

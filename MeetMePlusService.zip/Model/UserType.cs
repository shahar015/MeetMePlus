﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class UserType:BaseEntity
    {
        private string name;

        [DataMember]
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
    }

    [CollectionDataContract]
    public class UserTypesList : List<UserType>
    {
        public UserTypesList() { }
        public UserTypesList(IEnumerable<UserType> list) :
            base(list)
        { }
        public UserTypesList(IEnumerable<BaseEntity> list) :
            base(list.Cast<UserType>().ToList())
        { }

    }
}

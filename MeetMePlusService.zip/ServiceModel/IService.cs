﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ServiceModel
{
    [ServiceContract]
    public interface IService
    {
        #region Friends
        [OperationContract]
        FriendsList Friends_SelectAll();

        [OperationContract]
        Friend Friend_SelectById(int id);

        [OperationContract]
        int Friends_Insert(Friend friend);

        [OperationContract]
        int Friends_Update(Friend friend);

        [OperationContract]
        int Friends_Delete(Friend friend);

        [OperationContract]
        FriendsList Friend_SelectByUser(User user);

        [OperationContract]
        int Friends_DeleteByUser(User user);

        [OperationContract]
        Friend Friend_SelectByUsers(User user1, User user2);
        #endregion

        #region Users
        [OperationContract]
        UsersList Users_SelectAll();

        [OperationContract]
        User User_SelectById(int id);

        [OperationContract]
        UsersList User_Search(string text);

        [OperationContract]
        int Users_Insert(User user);

        [OperationContract]
        int Users_Update(User user);

        [OperationContract]
        int Users_Delete(User user);

        [OperationContract]
        User User_SelectLogin(string username, string password);

        [OperationContract]
        User User_FindUsername(string username);

        [OperationContract]
        UsersList User_SelectAllBesidesUser(User user);


        #endregion

        #region Meetings
        [OperationContract]
        MeetingsList Meetings_SelectAll();

        [OperationContract]
        Meeting Meeting_SelectById(int id);

        [OperationContract]
        MeetingsList Meetings_SelectByUser(User user);

        [OperationContract]
        int Meetings_Insert(Meeting meeting);

        [OperationContract]
        int Meetings_Update(Meeting meeting);

        [OperationContract]
        int Meetings_Delete(Meeting meeting);

        [OperationContract]
        MeetingsList Meetings_SelectAllBesidesUser(User user);

        [OperationContract]
        int Meetings_DeleteByUser(User user);
        #endregion

        #region Messages
        [OperationContract]
        MessagesList Messages_SelectAll();

        [OperationContract]
        Message Message_SelectById(int id);

        [OperationContract]
        MessagesList Message_SelectByChat(Chat chat);

        [OperationContract]
        MessagesList Message_SearchTextInChat(Chat chat, string text);

        [OperationContract]
        int Message_Insert(Message message);

        [OperationContract]
        int Message_Update(Message message);

        [OperationContract]
        int Message_Delete(Message message);

        [OperationContract]
        int Message_DeleteFromChat(Chat chat);

        [OperationContract]
        int Messages_DeleteByUser(User user);

        #endregion

        #region ParticipentsInMeeting
        [OperationContract]
        ParticipentsInMeetingList ParticipentsInMeeting_SelectAll();

        [OperationContract]
        ParticipentInMeeting ParticipentInMeeting_SelectById(int id);

        [OperationContract]
        ParticipentsInMeetingList ParticipentsInMeeting_SelectByUser(User user);

        [OperationContract]
        ParticipentsInMeetingList ParticipentsInMeeting_SelectByMeeting(Meeting meeting);

        [OperationContract]
        int ParticipentInMeeting_Insert(ParticipentInMeeting participentInMeeting);

        [OperationContract]
        int ParticipentInMeeting_Update(ParticipentInMeeting participentInMeeting);

        [OperationContract]
        int ParticipentInMeeting_Delete(ParticipentInMeeting participentInMeeting);

        [OperationContract]
        int ParticipentsInMeeting_DeleteByUser(User user);

        [OperationContract]
        int ParticipentsInMeeting_DeleteByMeeting(Meeting meeting);

        #endregion

        #region Chats
        [OperationContract]
        ChatsList Chat_SelectAll();

        [OperationContract]
        Chat Chat_SelectId(int id);

        [OperationContract]
        ChatsList Chat_SelectByUser(User user);

        [OperationContract]
        Chat Chat_SelectByUsers(User user1, User user2);

        [OperationContract]
        ChatsList Chat_SearchText(string text);

        [OperationContract]
        int Chat_Insert(Chat chat);

        [OperationContract]
        int Chat_Update(Chat chat);

        [OperationContract]
        int Chat_Delete(Chat chat);
        #endregion

        #region Images
        [OperationContract]
        byte[] GetProfPic(User user);

        [OperationContract]
        void SaveImage(byte[] imageArray, string fileName);

        [OperationContract]
        void DeleteImage(string fileName);
        #endregion

        #region UserTypes
        [OperationContract]
        UserTypesList UserTypes_SelectAll();

        [OperationContract]
        UserType UserType_SelectById(int id);

        [OperationContract]
        int UserTypes_Insert(UserType userType);

        [OperationContract]
        int UserTypes_Update(UserType userType);

        [OperationContract]
        int UserTypes_Delete(UserType userType);
        #endregion
    }
}

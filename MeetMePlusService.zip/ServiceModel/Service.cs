﻿using Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModel;

namespace ServiceModel
{
    public class Service : IService
    {
        #region Friends
        public FriendsList Friends_SelectAll()
        {
            FriendManager friend = new FriendManager();
            return friend.SelectAll();
        }

        public Friend Friend_SelectById(int id)
        {
            FriendManager friend = new FriendManager();
            return friend.SelectById(id);
        }

        public FriendsList Friend_SelectByUser(User user)
        {
            FriendManager friendManager = new FriendManager();
            return friendManager.SelectByUser(user);
        }

        public Friend Friend_SelectByUsers(User user1, User user2)
        {
            FriendManager friendManager = new FriendManager();
            return friendManager.SelectByUsers(user1, user2);
        }

        public int Friends_Insert(Friend friend)
        {
            FriendManager friendManager = new FriendManager();
            return friendManager.Insert(friend);
        }

        public int Friends_Update(Friend friend)
        {
            FriendManager friendManager = new FriendManager();
            return friendManager.Update(friend);
        }

        public int Friends_Delete(Friend friend)
        {
            FriendManager friendManager = new FriendManager();
            return friendManager.Delete(friend);
        }

        public int Friends_DeleteByUser(User user)
        {
            FriendManager friendManager = new FriendManager();
            return friendManager.DeleteByUser(user);
        }
        #endregion

        #region Meeting
        public MeetingsList Meetings_SelectAll()
        {
            MeetingManager meetings = new MeetingManager();
            return meetings.SelectAll();
        }

        public Meeting Meeting_SelectById(int id)
        {
            MeetingManager meetingManager = new MeetingManager();
            return meetingManager.SelectById(id);
        }

        public int Meetings_Insert(Meeting meeting)
        {
            MeetingManager meetingManager = new MeetingManager();
            return meetingManager.Insert(meeting);
        }

        public int Meetings_Update(Meeting meeting)
        {
            MeetingManager meetingManager = new MeetingManager();
            return meetingManager.Update(meeting);
        }

        public int Meetings_Delete(Meeting meeting)
        {
            MeetingManager meetingManager = new MeetingManager();
            return meetingManager.Delete(meeting);
        }

        public MeetingsList Meetings_SelectAllBesidesUser(User user)
        {
            MeetingManager meetingManager = new MeetingManager();
            return meetingManager.SelectAllBesidesUser(user);
        }

        public MeetingsList Meetings_SelectByUser(User user)
        {
            MeetingManager meetingManager = new MeetingManager();
            return meetingManager.SelectByUser(user);
        }

        public int Meetings_DeleteByUser(User user)
        {
            MeetingManager meetingManager = new MeetingManager();
            return meetingManager.DeleteByUser(user);
        }
        #endregion

        #region Messages
        public MessagesList Messages_SelectAll()
        {
            MessageManager messageManager = new MessageManager();
            return messageManager.SelectAll();
        }

        public Message Message_SelectById(int id)
        {
            MessageManager messageManager = new MessageManager();
            return messageManager.SelectById(id);
        }

        public MessagesList Message_SelectByChat(Chat chat)
        {
            MessageManager manager = new MessageManager();
            return manager.SelectByChat(chat);
        }

        public MessagesList Message_SearchTextInChat(Chat chat, string text)
        {
            MessageManager manager = new MessageManager();
            return manager.SearchTextInChat(chat, text);
        }

        public int Message_Insert(Message message)
        {
            MessageManager messageManager = new MessageManager();
            return messageManager.Insert(message);
        }

        public int Message_Update(Message message)
        {
            MessageManager messageManager = new MessageManager();
            return messageManager.Update(message);
        }

        public int Message_Delete(Message message)
        {
            MessageManager messageManager = new MessageManager();
            return messageManager.Delete(message);
        }

        public int Message_DeleteFromChat(Chat chat)
        {
            MessageManager messageManager = new MessageManager();
            return messageManager.DeleteFromChat(chat);
        }

        public int Messages_DeleteByUser(User user)
        {
            MessageManager messageManager = new MessageManager();
            return messageManager.DeleteByUser(user);
        }

        #endregion

        #region ParticipentsInMeeting
        public ParticipentsInMeetingList ParticipentsInMeeting_SelectAll()
        {
            ParticipentsInMeetingManager participentsInMeetingManager =
                new ParticipentsInMeetingManager();
            return participentsInMeetingManager.SelectAll();
        }

        public ParticipentInMeeting ParticipentInMeeting_SelectById(int id)
        {
            ParticipentsInMeetingManager meetingManager = new ParticipentsInMeetingManager();
            return meetingManager.SelectById(id);
        }

        public ParticipentsInMeetingList ParticipentsInMeeting_SelectByUser(User user)
        {
            ParticipentsInMeetingManager meetingManager = new ParticipentsInMeetingManager();
            return meetingManager.SelectByUser(user);
        }

        public ParticipentsInMeetingList ParticipentsInMeeting_SelectByMeeting(Meeting meeting)
        {
            ParticipentsInMeetingManager meetingManager = new ParticipentsInMeetingManager();
            return meetingManager.SelectByMeeting(meeting);
        }

        public int ParticipentInMeeting_Insert(ParticipentInMeeting participentInMeeting)
        {
            ParticipentsInMeetingManager meetingManager = new ParticipentsInMeetingManager();
            return meetingManager.Insert(participentInMeeting);
        }

        public int ParticipentInMeeting_Update(ParticipentInMeeting participentInMeeting)
        {
            ParticipentsInMeetingManager meetingManager = new ParticipentsInMeetingManager();
            return meetingManager.Update(participentInMeeting);
        }

        public int ParticipentInMeeting_Delete(ParticipentInMeeting participentInMeeting)
        {
            ParticipentsInMeetingManager meetingManager = new ParticipentsInMeetingManager();
            return meetingManager.Delete(participentInMeeting);
        }

        public int ParticipentsInMeeting_DeleteByUser(User user)
        {
            ParticipentsInMeetingManager meetingManager = new ParticipentsInMeetingManager();
            return meetingManager.DeleteByUser(user);
        }

        public int ParticipentsInMeeting_DeleteByMeeting(Meeting meeting)
        {
            ParticipentsInMeetingManager meetingManager = new ParticipentsInMeetingManager();
            return meetingManager.DeleteByMeeting(meeting);
        }
        #endregion

        #region Users
        public UsersList Users_SelectAll()
        {
            UserManager userManager = new UserManager();
            return userManager.SelectAll();
        }

        public User User_SelectById(int id)
        {
            UserManager userManager = new UserManager();
            return userManager.SelectById(id);
        }

        public UsersList User_SelectAllBesidesUser(User user)
        {
            UserManager userManager = new UserManager();
            return userManager.SelectAllBesidesUser(user);
        }

        public UsersList User_Search(string text)
        {
            UserManager manager = new UserManager();
            return manager.SearchByText(text);
        }

        public int Users_Insert(User user)
        {
            UserManager userManager = new UserManager();
            return userManager.Insert(user);
        }

        public int Users_Update(User user)
        {
            UserManager userManager = new UserManager();
            return userManager.Update(user);
        }

        public int Users_Delete(User user)
        {
            UserManager userManager = new UserManager();
            return userManager.Delete(user);
        }

        public User User_SelectLogin(string username, string password)
        {
            UserManager userManager = new UserManager();
            return userManager.SelectLogin(username, password);
        }

        public User User_FindUsername(string username)
        {
            UserManager userManager = new UserManager();
            return userManager.FindUsername(username);
        }
        #endregion

        #region Chats
        public ChatsList Chat_SelectAll()
        {
            ChatManager chatManager = new ChatManager();
            return chatManager.SelectAll();
        }

        public Chat Chat_SelectId(int id)
        {
            ChatManager chatManager = new ChatManager();
            return chatManager.SelectById(id);
        }

        public ChatsList Chat_SearchText(string text)
        {
            ChatManager manager = new ChatManager();
            return manager.SearchText(text);
        }

        public ChatsList Chat_SelectByUser(User user)
        {
            ChatManager manager = new ChatManager();
            return manager.SelectByUser(user);
        }

        public Chat Chat_SelectByUsers(User user1, User user2)
        {
            ChatManager manager = new ChatManager();
            return manager.SelectByUsers(user1, user2);
        }

        public int Chat_Insert(Chat chat)
        {
            ChatManager chatManager = new ChatManager();
            return chatManager.Insert(chat);
        }

        public int Chat_Update(Chat chat)
        {
            ChatManager chatManager = new ChatManager();
            return chatManager.Update(chat);
        }

        public int Chat_Delete(Chat chat)
        {
            ChatManager chatManager = new ChatManager();
            return chatManager.Delete(chat);
        }

        #endregion

        #region Images
        public byte[] GetProfPic(User user)
        {
            //ViewModel הנחה: הקובץ קיים ושמור בתיקיית תמונות בתוך
            //הפרמטר כולל רק את שם הקובץ
            string path = Path.Combine(
                Environment.CurrentDirectory,
                @"..\..\..\ViewModel\Images\" + user.Username + user.ProfPicExt);
            if (!File.Exists(path))
                return null;

            byte[] imgArray = File.ReadAllBytes(path);
            return imgArray;
        }

        public void SaveImage(byte[] imageArray, string fileName)
        {
            MemoryStream stream = new MemoryStream(imageArray);
            System.Drawing.Image image = System.Drawing.Image.FromStream(stream);

            string localFilePath = Path.Combine(
                Environment.CurrentDirectory,
                @"..\..\..\ViewModel\Images\" + fileName
            );
            image.Save(localFilePath);
        }

        public void DeleteImage(string fileName)
        {
            if (fileName != "default.png")
            {
                string localFilePath = Path.Combine(
                    Environment.CurrentDirectory,
                    @"..\..\..\ViewModel\Images\" + fileName
                );
                if (File.Exists(localFilePath))
                    File.Delete(localFilePath);

            }
        }
        #endregion

        #region UserTypes
        public UserTypesList UserTypes_SelectAll()
        {
            UserTypeManager userTypeManager = new UserTypeManager();
            return userTypeManager.SelectAll();
        }

        public UserType UserType_SelectById(int id)
        {
            UserTypeManager userTypeManager = new UserTypeManager();
            return userTypeManager.SelectById(id);
        }

        public int UserTypes_Insert(UserType userType)
        {
            UserTypeManager userTypeManager = new UserTypeManager();
            return userTypeManager.Insert(userType);
        }

        public int UserTypes_Update(UserType userType)
        {
            UserTypeManager userTypeManager = new UserTypeManager();
            return userTypeManager.Update(userType);
        }

        public int UserTypes_Delete(UserType userType)
        {
            UserTypeManager userTypeManager = new UserTypeManager();
            return userTypeManager.Delete(userType);
        }
        #endregion
    }
}

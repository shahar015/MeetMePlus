﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModel
{
    public class ChatManager:BaseDB
    {
        protected override BaseEntity NewEntity()
        {
            return new Chat() as BaseEntity;
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            Chat chat = (Chat)entity;
            chat.Id = int.Parse(reader["id"].ToString());
            UserManager user = new UserManager();
            chat.User1 = user.SelectById(int.Parse(reader["user1"].ToString()));
            chat.User2 = user.SelectById(int.Parse(reader["user2"].ToString()));
            return chat;
        }



        public ChatsList SelectAll()
        {
            command.CommandText = "SELECT * FROM tblchats";
            ChatsList chatsList = new ChatsList(base.Select());
            return chatsList;
        }

        public Chat SelectById(int id)
        {
            command.CommandText = string.Format("SELECT * FROM tblchats WHERE id='{0}'", id);
            ChatsList chatsList = new ChatsList(base.Select());
            if (chatsList.Count == 0)
            {
                return null;
            }
            return chatsList[0];
        }

        public ChatsList SelectByUser(User user)
        {
            command.CommandText = "SELECT * FROM tblchats WHERE (user1=@user1 OR user2=@user1) ";
            command.Parameters.AddWithValue("@user1", user.Id);
            ChatsList list = new ChatsList(base.Select());
            return list;
        }
        public Chat SelectByUsers(User user, User other)
        {
            command.CommandText = "SELECT * FROM tblchats WHERE (user1=@user1 AND user2=@user2)" +
                " OR (user1=@user2 AND user2=@user1)";
            command.Parameters.AddWithValue("@user1", user.Id);
            command.Parameters.AddWithValue("@user2", other.Id);
            ChatsList list = new ChatsList(base.Select());
            if (list.Count == 0)
                return null;
            return list[0];
        }

        public ChatsList SearchText(string text)
        {
            command.CommandText = "SELECT tblchats.* FROM tblchats INNER JOIN tblmessages ON tblchats.id = tblmessages.chat " +
                "WHERE (tblmessages.content LIKE N'@text%')";
            command.Parameters.AddWithValue("@text", text);
            ChatsList list = new ChatsList(base.Select());
            return list;
        }

        public int Insert(Chat chat)
        {
            command.CommandText = string.Format("INSERT INTO tblchats (user1, user2) VALUES (@user1, @user2)");
            command.Parameters.AddWithValue("@user1", chat.User1.Id);
            command.Parameters.AddWithValue("@user2", chat.User2.Id);
            return base.SaveChanges();
        }

        public int Update(Chat chat)
        {
            command.CommandText = string.Format("UPDATE tblchats SET user1 = @user1, user2 = @user2 WHERE ((id = @Original_Id)");
            command.Parameters.AddWithValue("@user1", chat.User1);
            command.Parameters.AddWithValue("@user2", chat.User2);
            command.Parameters.AddWithValue("@Original_Id", chat.Id);
            return base.SaveChanges();
        }

        public int Delete(Chat chat)
        {
            command.CommandText = string.Format("DELETE FROM tblchats WHERE ((id = @Original_Id))");
            command.Parameters.AddWithValue("@Original_Id", chat.Id);
            return base.SaveChanges();
        }
    }
}

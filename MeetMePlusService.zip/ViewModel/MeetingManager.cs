﻿using Model;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModel
{
    public class MeetingManager : BaseDB
    {
        protected override BaseEntity NewEntity()
        {
            return new Meeting() as BaseEntity;
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            Meeting meeting = (Meeting)entity;
            meeting.Id = int.Parse(reader["id"].ToString());
            UserManager user = new UserManager();
            meeting.Creator = user.SelectById(int.Parse(reader["creator"].ToString()));
            meeting.Description = reader["description"].ToString();
            meeting.Location = reader["location"].ToString();
            meeting.Name = reader["name"].ToString();
            meeting.MeetingTime = DateTime.ParseExact(reader["meetingTime"].ToString(), "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
            return meeting;
        }



        public MeetingsList SelectAll()
        {
            command.CommandText = "SELECT * FROM tblmeetings";
            MeetingsList meetingsList = new MeetingsList(base.Select());
            return meetingsList;
        }

        public Meeting SelectById(int id)
        {
            command.CommandText = string.Format("SELECT * FROM tblmeetings WHERE id='{0}'", id);
            MeetingsList meetingsList = new MeetingsList(base.Select());
            if (meetingsList.Count == 0)
            {
                return null;
            }
            return meetingsList[0];

        }

        public MeetingsList SelectAllBesidesUser(User user)
        {
            command.CommandText = string.Format("SELECT * FROM tblmeetings WHERE creator<>'{0}'", user.Id);
            MeetingsList meetings = new MeetingsList(base.Select());
            return meetings;
        }

        public MeetingsList SelectByUser(User user)
        {
            command.CommandText = string.Format("SELECT * FROM tblmeetings WHERE creator='{0}'", user.Id);
            MeetingsList meetings = new MeetingsList(base.Select());
            return meetings;
        }

        public int Insert(Meeting meeting)
        {
            command.CommandText = string.Format("INSERT INTO tblmeetings (creator, description, location, name, meetingTime) VALUES (@creator, @description, @location, @name, @meetingTime)");
            command.Parameters.AddWithValue("@creator", meeting.Creator.Id);
            command.Parameters.AddWithValue("@description", meeting.Description);
            command.Parameters.AddWithValue("@name", meeting.Name);
            command.Parameters.AddWithValue("@location", meeting.Location);
            command.Parameters.AddWithValue("@meetingTime", meeting.MeetingTime.ToString("dd/MM/yyyy HH:mm"));
            return base.SaveChanges();
        }

        public int Update(Meeting meeting)
        {
            command.CommandText = string.Format("UPDATE tblmeetings SET creator = @creator, description = @description, location = @location, name = @name, meetingTime = @meetingTime WHERE ((id = @Original_Id))");
            command.Parameters.AddWithValue("@creator", meeting.Creator.Id);
            command.Parameters.AddWithValue("@description", meeting.Description);
            command.Parameters.AddWithValue("@name", meeting.Name);
            command.Parameters.AddWithValue("@location", meeting.Location);
            command.Parameters.AddWithValue("@meetingTime", meeting.MeetingTime.ToString("dd/MM/yyyy HH:mm"));
            command.Parameters.AddWithValue("@Original_Id", meeting.Id);
            return base.SaveChanges();
        }

        public int Delete(Meeting meeting)
        {
            command.CommandText = string.Format("DELETE FROM tblmeetings WHERE ((id = @Original_Id))");
            command.Parameters.AddWithValue("@Original_Id", meeting.Id);
            return base.SaveChanges();
        }
        public int DeleteByUser(User user)
        {
            command.CommandText = string.Format("DELETE FROM tblmeetings WHERE ((creator = @Original_Id))");
            command.Parameters.AddWithValue("@Original_Id", user.Id);
            return base.SaveChanges();
        }

    }
}

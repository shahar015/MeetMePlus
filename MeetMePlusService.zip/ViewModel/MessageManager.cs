﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModel
{
    public class MessageManager : BaseDB
    {
        protected override BaseEntity NewEntity()
        {
            return new Message() as BaseEntity;
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            Message message = (Message)entity;
            message.Id = int.Parse(reader["id"].ToString());
            UserManager user = new UserManager();
            message.Sender = user.SelectById(int.Parse(reader["sender"].ToString()));
            message.SendingTime = DateTime.Parse(reader["sendingTime"].ToString());
            message.Content = reader["content"].ToString();
            ChatManager chat=new ChatManager();
            message.Chat = chat.SelectById(int.Parse(reader["chat"].ToString()));
            return message;
        }



        public MessagesList SelectAll()
        {
            command.CommandText = "SELECT * FROM tblmessages";
            MessagesList messagesList = new MessagesList(base.Select());
            return messagesList;
        }

        public Message SelectById(int id)
        {
            command.CommandText = string.Format("SELECT * FROM tblmessages WHERE id='{0}'", id);
            MessagesList messagesList = new MessagesList(base.Select());
            if (messagesList.Count == 0)
            {
                return null;
            }
            return messagesList[0];

        }

        public MessagesList SelectByChat(Chat chat)
        {
            command.CommandText = "SELECT * FROM tblmessages WHERE chat=@ChatID";
            command.Parameters.AddWithValue("@ChatID", chat.Id);
            MessagesList list = new MessagesList(base.Select());
            return list;
        }
        public MessagesList SearchTextInChat(Chat chat, string text)
        {
            command.CommandText = "SELECT * FROM tblmessages WHERE chat=@chatID content LIKE N'@text%'";
            command.Parameters.AddWithValue("@text", text);
            command.Parameters.AddWithValue("@chatID", chat.Id);
            MessagesList list = new MessagesList(base.Select());
            return list;
        }

        public int Insert(Message message)
        {
            command.CommandText = string.Format("INSERT INTO tblmessages (sender, sendingTime, content, chat) VALUES (@sender, @sendingTime, @content, @chat);");
            command.Parameters.AddWithValue("@sender", message.Sender.Id);
            command.Parameters.AddWithValue("@sendingTime", message.SendingTime);
            command.Parameters.AddWithValue("@content", message.Content);
            command.Parameters.AddWithValue("@chat", message.Chat.Id);
            return base.SaveChanges();
        }

        public int Update(Message message)
        {
            command.CommandText = string.Format("UPDATE tblmessages SET sender = @sender, sendingTime = @sendingTime, content = @content, chat = @chat WHERE ((id = @Original_Id)");
            command.Parameters.AddWithValue("@sender", message.Sender.Id);
            command.Parameters.AddWithValue("@sendingTime", message.SendingTime);
            command.Parameters.AddWithValue("@content", message.Content);
            command.Parameters.AddWithValue("@chat", message.Chat.Id);
            command.Parameters.AddWithValue("@Original_Id", message.Id);
            return base.SaveChanges();
        }

        public int Delete(Message message)
        {
            command.CommandText = string.Format("DELETE FROM tblmessages WHERE ((id = @Original_Id))");
            command.Parameters.AddWithValue("@Original_Id", message.Id);
            return base.SaveChanges();
        }

        public int DeleteFromChat(Chat chat)
        {
            command.CommandText = string.Format("DELETE FROM tblmessages WHERE ((chat = @Chat_Id))");
            command.Parameters.AddWithValue("@Chat_Id", chat.Id);
            return base.SaveChanges();
        }

        public int DeleteByUser(User user)
        {
            command.CommandText = string.Format("DELETE FROM tblmessages WHERE (sender = @Original_Id)");
            command.Parameters.AddWithValue("@Original_Id", user.Id);
            return base.SaveChanges();
        }
    }
}

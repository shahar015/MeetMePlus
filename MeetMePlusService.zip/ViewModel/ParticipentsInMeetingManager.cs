﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModel
{
    public class ParticipentsInMeetingManager : BaseDB
    {
        protected override BaseEntity NewEntity()
        {
            return new ParticipentInMeeting() as BaseEntity;
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            ParticipentInMeeting participentInMeeting = (ParticipentInMeeting)entity;
            participentInMeeting.Id = int.Parse(reader["id"].ToString());
            UserManager user = new UserManager();
            participentInMeeting.Participent = user.SelectById(int.Parse(reader["participent"].ToString()));
            MeetingManager meeting = new MeetingManager();
            participentInMeeting.Meeting = meeting.SelectById(int.Parse(reader["meeting"].ToString()));
            return participentInMeeting;
        }



        public ParticipentsInMeetingList SelectAll()
        {
            command.CommandText = "SELECT * FROM tblparticipentsinmeeting";
            ParticipentsInMeetingList participentsInMeetingList = new ParticipentsInMeetingList(base.Select());
            return participentsInMeetingList;
        }

        public ParticipentInMeeting SelectById(int id)
        {
            command.CommandText = string.Format("SELECT * FROM tblparticipentsinmeeting WHERE id='{0}'", id);
            ParticipentsInMeetingList participentsInMeetingList = new ParticipentsInMeetingList(base.Select());
            if (participentsInMeetingList.Count == 0)
            {
                return null;
            }
            return participentsInMeetingList[0];

        }

        public ParticipentsInMeetingList SelectByUser(User user)
        {
            command.CommandText = string.Format("SELECT * FROM tblparticipentsinmeeting WHERE participent='{0}'", user.Id);
            ParticipentsInMeetingList participentsInMeetingList = new ParticipentsInMeetingList(base.Select());
            return participentsInMeetingList;
        }

        public ParticipentsInMeetingList SelectByMeeting(Meeting meeting)
        {
            command.CommandText = string.Format("SELECT * FROM tblparticipentsinmeeting WHERE meeting='{0}'", meeting.Id);
            ParticipentsInMeetingList participentsInMeetingList = new ParticipentsInMeetingList(base.Select());
            return participentsInMeetingList;
        }

        public int Insert(ParticipentInMeeting participentInMeeting)
        {
            command.CommandText = string.Format("INSERT INTO tblparticipentsinmeeting (participent, meeting) VALUES (@participent, @meeting)");
            command.Parameters.AddWithValue("@participent", participentInMeeting.Participent.Id);
            command.Parameters.AddWithValue("@meeting", participentInMeeting.Meeting.Id);
            return base.SaveChanges();
        }

        public int Update(ParticipentInMeeting participentInMeeting)
        {
            command.CommandText = string.Format("UPDATE tblparticipentsinmeeting SET participent = @participent, meeting = @meeting WHERE ((id = @Original_id)");
            command.Parameters.AddWithValue("@participent", participentInMeeting.Participent.Id );
            command.Parameters.AddWithValue("@meeting", participentInMeeting.Meeting.Id);
            command.Parameters.AddWithValue("@Original_id", participentInMeeting.Id);
            return base.SaveChanges();
        }

        public int Delete(ParticipentInMeeting participentInMeeting)
        {
            command.CommandText = string.Format("DELETE FROMtblparticipentsinmeeting WHERE (id = @Original_id)");
            command.Parameters.AddWithValue("@Original_id", participentInMeeting.Id);
            return base.SaveChanges();
        }

        public int DeleteByUser(User user)
        {
            command.CommandText = string.Format("DELETE FROM tblparticipentsinmeeting WHERE (participent = @Original_id)");
            command.Parameters.AddWithValue("@Original_id", user.Id);
            return base.SaveChanges();
        }

        public int DeleteByMeeting(Meeting meeting)
        {
            command.CommandText = string.Format("DELETE FROM tblparticipentsinmeeting WHERE (meeting = @Original_id)");
            command.Parameters.AddWithValue("@Original_id", meeting.Id);
            return base.SaveChanges();
        }
    }
}

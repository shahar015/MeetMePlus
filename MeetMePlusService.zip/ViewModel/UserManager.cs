﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModel
{
    public class UserManager : BaseDB
    {

        protected override BaseEntity NewEntity()
        {
            return new User() as BaseEntity;
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            User user = (User)entity;
            user.Id = int.Parse(reader["id"].ToString());
            user.Username = reader["username"].ToString();
            user.Password = reader["password"].ToString();
            user.FirstName = reader["firstName"].ToString();
            user.LastName = reader["lastName"].ToString();
            user.Phone = reader["phone"].ToString();
            user.Email = reader["email"].ToString();
            user.Birthday = DateTime.Parse(reader["birthday"].ToString());
            List<string> list = reader["interests"].ToString().Split(',').ToList();
            user.Interests = list;
            user.Gender = bool.Parse(reader["Gender"].ToString());
            user.ProfPicExt = reader["profPicExt"].ToString();
            UserTypeManager userType = new UserTypeManager();
            user.UserType = userType.SelectById(int.Parse(reader["userType"].ToString()));
            user.ProfPicExt = reader["profPicExt"].ToString();
            return user;
        }

        public UsersList SelectAll()
        {
            command.CommandText = "SELECT * FROM tblusers";
            UsersList userList = new UsersList(base.Select());
            return userList;
        }

        public User SelectById(int id)
        {
            command.CommandText = string.Format("SELECT * FROM tblusers WHERE id='{0}'", id);
            UsersList usersList = new UsersList(base.Select());
            if (usersList.Count == 0)
            {
                return null;
            }
            return usersList[0];

        }

        public UsersList SelectAllBesidesUser(User user)
        {
            command.CommandText = string.Format("SELECT * FROM tblusers WHERE id<>'{0}'", user.Id);
            UsersList userList = new UsersList(base.Select());
            return userList;
        }

        public User SelectLogin(string username, string password)
        {
            command.CommandText = string.Format("SELECT * FROM tblusers " +
                "WHERE username=N'{0}' AND password=N'{1}'", username, password);
            UsersList usersList = new UsersList(base.Select());
            if (usersList.Count == 0)
            {
                return null;
            }
            return usersList[0];
        }


        public int Insert(User user)
        {
            command.CommandText = string.Format("INSERT INTO tblusers (username, password, firstName, lastName, gender, phone, birthday, email, interests, profPicExt, userType) " +
                "VALUES (@username, @password, @firstName, @lastName, @gender, @phone, @birthday, @email, @interests, @profPicExt, @userType);");
            command.Parameters.AddWithValue("@username", user.Username);
            command.Parameters.AddWithValue("@password", user.Password);
            command.Parameters.AddWithValue("@firstName", user.FirstName);
            command.Parameters.AddWithValue("@lastName", user.LastName);
            command.Parameters.AddWithValue("@gender", user.Gender);
            command.Parameters.AddWithValue("@phone", user.Phone);
            command.Parameters.AddWithValue("@birthday", user.Birthday);
            command.Parameters.AddWithValue("@email", user.Email);
            command.Parameters.AddWithValue("@interests", string.Join(",", user.Interests));
            command.Parameters.AddWithValue("@profPicExt", user.ProfPicExt);
            command.Parameters.AddWithValue("@userType", user.UserType.Id);
            return base.SaveChanges();
        }

        public int Update(User user)
        {
            command.CommandText = string.Format("UPDATE tblusers SET username = @username, password = @password, firstName = @firstName," +
                " lastName = @lastName, gender=@gender, phone = @phone, birthday = @birthday, email = @email, interests = @interests, profPicExt = @profPicExt, userType = @userType " +
                "WHERE (id = @Original_id);");
            command.Parameters.AddWithValue("@username", user.Username);
            command.Parameters.AddWithValue("@password", user.Password);
            command.Parameters.AddWithValue("@firstName", user.FirstName);
            command.Parameters.AddWithValue("@lastName", user.LastName);
            command.Parameters.AddWithValue("@gender", user.Gender);
            command.Parameters.AddWithValue("@phone", user.Phone);
            command.Parameters.AddWithValue("@birthday", user.Birthday);
            command.Parameters.AddWithValue("@email", user.Email);
            command.Parameters.AddWithValue("@interests", string.Join(",", user.Interests));
            command.Parameters.AddWithValue("@profPicExt", user.ProfPicExt);
            command.Parameters.AddWithValue("@userType", user.UserType.Id);
            command.Parameters.AddWithValue("@Original_id", user.Id);
            return base.SaveChanges();
        }

        public int Delete(User user)
        {
            command.CommandText = string.Format("DELETE FROM tblusers WHERE (id = @Original_id)");
            command.Parameters.AddWithValue("@Original_id", user.Id);
            return base.SaveChanges();
        }

        public User FindUsername(string username)
        {
            command.CommandText = string.Format("SELECT * FROM tblusers WHERE username='{0}'", username);
            UsersList usersList = new UsersList(base.Select());
            if (usersList.Count == 0)
            {
                return null;
            }
            return usersList[0];

        }

        public UsersList SearchByText(string text)
        {
            command.CommandText = string.Format(" SELECT * FROM tblusers WHERE " +
                "firstName LIKE '%{0}%'",text);
            UsersList list = new UsersList(base.Select());
            return list;
        }

    }
}

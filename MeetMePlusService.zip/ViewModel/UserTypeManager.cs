﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewModel
{
    public class UserTypeManager : BaseDB
    {
        protected override BaseEntity NewEntity()
        {
            return new UserType() as BaseEntity;
        }

        protected override BaseEntity CreateModel(BaseEntity entity)
        {
            UserType userType = (UserType)entity;
            userType.Id = int.Parse(reader["id"].ToString());
            userType.Name = reader["name"].ToString();
            return userType;
        }

        public UserTypesList SelectAll()
        {
            command.CommandText = "SELECT * FROM tblusertypes";
            UserTypesList userTypesList = new UserTypesList(base.Select());
            return userTypesList;
        }

        public UserType SelectById(int id)
        {
            command.CommandText = string.Format("SELECT * FROM tblusertypes WHERE id='{0}'", id);
            UserTypesList userTypesList = new UserTypesList(base.Select());
            if (userTypesList.Count == 0)
            {
                return null;
            }
            return userTypesList[0];
        }

        public int Insert(UserType userType)
        {
            command.CommandText = string.Format("INSERT INTO tblusertypes (name) " +
                "VALUES (@name)");
            command.Parameters.AddWithValue("@name", userType.Name);
            return base.SaveChanges();
        }

        public int Update(UserType userType)
        {
            command.CommandText = string.Format("UPDATE tblusertypes SET name = @name" +
                " WHERE (id = @Original_id);");
            command.Parameters.AddWithValue("@name", userType.Name);
            command.Parameters.AddWithValue("@Original_id", userType.Id);
            return base.SaveChanges();
        }

        public int Delete(UserType userType)
        {
            command.CommandText = string.Format("DELETE FROM tblusertypes WHERE (id = @Original_id)");
            command.Parameters.AddWithValue("@Original_id", userType.Id);
            return base.SaveChanges();
        }

    }
}
